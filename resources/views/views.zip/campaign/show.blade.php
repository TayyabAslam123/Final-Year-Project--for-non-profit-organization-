@extends('layout.master')

@section('content')




<div class="jumbotron">
    <div class="container-fluid">
      



        <div class="row">
          <div class="col-lg-6" >
              <img src="{{$post->img}}" height="400PX" width="450px">
              <h2>AMOUNT REQUIRED: {{$post->amount_req}}</h2>
              <h2>AMOUNT RAISED:{{$post->amount_raised}}</h2>
          </div>
          <div class="col-lg-6">
              <h1>{{$post->title}}</h1>
              <p>{{$post->body}}</p>
          </div>
        </div>
      </div>
      
<hr>
<hr>

        <hr>     
        @if(!Auth::guest())
<a href="http://localhost/AdminPanel/public/campaign/{{$post->id}}/edit">
    <button class="btn btn-primary btn-lg btn-block">
    EDIT
    </button>
    </a>                

    <br>
    <br>

    {!!Form::open(['action'=>['CampaignController@destroy',$post->id],'method'=>'post'])!!}

    {{Form::hidden('_method','DELETE')}}
    
    <button class="btn btn-danger btn-lg btn-block">
           DELETE
            </button>
    {!!Form::close()!!}

    @endif
</div>
<br>


<div id="fb-root"></div>
<script>(function(d, s, id) {
var js, fjs = d.getElementsByTagName(s)[0];
if (d.getElementById(id)) return;
js = d.createElement(s); js.id = id;
js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.0";
fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<!-- Your share button code -->
<div class="fb-share-button "  
data-href="<?php echo 'http://www.goodwill.com' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" 
data-layout="button_count" style="height:150px;width:300px">
</div>

</div>
<!---->
<script
var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange=function(){
      if(this.readyState==4&& this.status==200){
        document.getElementById('dm').innerHTML=this.responseText;
        console.log(this.responseText);
      }
  };
  xhttp.open("GET", 'http://localhost:8001/load.php?user_type=customer&location={{$project->city}}&category={{$project->category}}&desc={{str_word_count($project->description)}}&product=yes&amt={{$project->amount_required}}', true);
xhttp.send();
</script>


@endsection