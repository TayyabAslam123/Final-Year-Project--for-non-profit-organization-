@extends('layout.master')

@section('content')
<h2>WELCOME! ADMIN</h2>

  <!-- Basic Card Example -->
  
  @endsection
